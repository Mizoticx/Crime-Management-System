async function checkCNIC() {
  const input = document.getElementById("cnicInput").value.trim();
  const resultDiv = document.getElementById("result");

  if (!input) {
    alert("Please enter CNIC");
    return;
  }

  const normalizedCNIC = input.replace(/-/g, "");
  resultDiv.innerHTML = `<p>🔍 Checking record...</p>`;

  try {
    const res = await fetch(
      `http://localhost:3000/search/cnic/${encodeURIComponent(normalizedCNIC)}`
    );

    const data = await res.json();

    if (
      data.criminalRecord.length === 0 &&
      data.firRecord.length === 0
    ) {
      resultDiv.innerHTML =
        `<p class="no-record">No Criminal or FIR Record Found</p>`;
      return;
    }

    let html = `<div class="record-found"><h3>⚠ Record Found</h3>`;

    // CRIMINAL RECORD
    if (data.criminalRecord.length > 0) {
      const c = data.criminalRecord[0];

      html += `
        <div class="record-card">
          <div class="record-header">
            <h4>Criminal Details</h4>
            <button class="delete-btn"
              onclick="deleteRecord('${c.cnic}')">
               Delete
            </button>
          </div>

          <p><b>CNIC:</b> ${c.cnic}</p>
          <p><b>Name:</b> ${c.name}</p>
          <p><b>Age:</b> ${c.age}</p>
          <p><b>Gender:</b> ${c.gender}</p>
          <p><b>Crime History:</b> ${c.crime_history}</p>
          <p><b>Address:</b> ${c.address}</p>
        </div>
      `;
    }

    // FIR RECORDS
    if (data.firRecord.length > 0) {
      html += `<h4>FIR Records</h4>`;
      data.firRecord.forEach(f => {
        html += `
          <div class="record-card">
            <p><b>FIR ID:</b> ${f.fir_id}</p>
            <p><b>Date:</b> ${f.fir_date}</p>
            <p><b>Description:</b> ${f.description}</p>
          </div>
        `;
      });
    }

    html += `</div>`;
    resultDiv.innerHTML = html;

  } catch (err) {
    console.error(err);
    resultDiv.innerHTML =
      `<p style="color:red;">Server Error</p>`;
  }
}

/* 🔴 DELETE FUNCTION MUST BE OUTSIDE */
async function deleteRecord(cnic) {
  if (!confirm("Are you sure you want to delete this record?")) return;

  try {
    const res = await fetch(
      `http://localhost:3000/search/remove/${cnic}`,
      { method: "DELETE" }
    );

    const data = await res.json();

    if (data.success) {
      document.getElementById("result").innerHTML =
        `<p class="no-record">✅ Record deleted successfully</p>`;
    } else {
      alert("Delete failed");
    }

  } catch (err) {
    console.error(err);
    alert("Server error");
  }
}
