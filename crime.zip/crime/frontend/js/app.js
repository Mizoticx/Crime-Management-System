const form = document.getElementById("criminalForm");
const table = document.getElementById("criminalTable");
if (form) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const data = {
      name: document.getElementById("name").value,
      age: document.getElementById("age").value,
      cnic: document.getElementById("cnic").value,
      gender: document.getElementById("gender").value,
      crime_history: document.getElementById("history").value,
      address: document.getElementById("address").value
    };

    const res = await fetch("http://localhost:3000/criminals/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    const msg = await res.text();
    alert(msg);

    form.reset();
  });
}

async function loadCriminals() {
  if (!table) return;

  const res = await fetch("http://localhost:3000/criminals");
  const criminals = await res.json();

  table.innerHTML = `
    <tr>
      <th>CNIC</th>
      <th>Name</th>
      <th>Age</th>
      <th>Gender</th>
      <th>History</th>
      <th>Address</th>
    </tr>
  `;

  criminals.forEach(c => {
    table.innerHTML += `
      <tr>
        
        <td>${c.name}</td>
        <td>${c.age}</td>
        <td>${c.gender}</td>
        <td>${c.crime_history}</td>
        <td>${c.address}</td>
        <td>${c.cnic || ""}</td>
      </tr>
    `;
  });
}
loadCriminals();
