CREATE DATABASE crime_db;
USE crime_db;

CREATE TABLE police (
    police_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    rank VARCHAR(50),
    station_name VARCHAR(100),
    contact VARCHAR(20)
);

CREATE TABLE criminals (
    criminal_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    gender VARCHAR(10),
    crime_history TEXT,
    address TEXT,
    cnic VARCHAR(13) UNIQUE
);

CREATE TABLE crimes (
    crime_id INT AUTO_INCREMENT PRIMARY KEY,
    crime_type VARCHAR(100),
    crime_date DATE,
    location VARCHAR(100),
    description TEXT,
    cnic VARCHAR(13) UNIQUE
);

CREATE TABLE cases (
    case_id INT AUTO_INCREMENT PRIMARY KEY,
    crime_id INT,
    police_id INT,
    start_date DATE,
    details TEXT,
    FOREIGN KEY (crime_id) REFERENCES crimes(crime_id),
    FOREIGN KEY (police_id) REFERENCES police(police_id),
    cnic VARCHAR(13) UNIQUE
);

CREATE TABLE fir (
    fir_id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT,
    victim_name VARCHAR(100),
    fir_date DATE,
    description TEXT,
    FOREIGN KEY (case_id) REFERENCES cases(case_id),
    cnic VARCHAR(13) UNIQUE
);

CREATE TABLE case_status (
    status_id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT,
    status VARCHAR(50),
    last_updated DATE,
    FOREIGN KEY (case_id) REFERENCES cases(case_id),
    cnic VARCHAR(13) UNIQUE
);
