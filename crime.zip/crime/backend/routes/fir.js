const express = require("express");
const router = express.Router();
const db = require("../db");

router.post("/add", (req, res) => {
  const { cnic, fir_date, description } = req.body;

  db.query(
    "INSERT INTO fir (cnic, fir_date, description) VALUES (?, ?, ?)",
    [cnic, fir_date, description],
    (err) => {
      if (err) return res.status(500).json({ success: false });

      res.json({ success: true });
    }
  );
});

module.exports = router;
