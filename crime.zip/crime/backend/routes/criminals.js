const express = require("express");
const db = require("../db");
const router = express.Router();

router.post("/add", (req, res) => {
  const { name, age, gender, crime_history, address, cnic } = req.body;
  const sql = `INSERT INTO criminals 
    (name, age, gender, crime_history, address, cnic)
    VALUES (?, ?, ?, ?, ?, ?)
  `;
  db.query(
    sql,
    [name, age, gender, crime_history, address, cnic],
    (err) => {
      if (err) {
        console.log(err);
        res.send(err.sqlMessage);
      } else {
        res.send("Criminal added successfully");
      }
    }
  );
});

// Get criminals
router.get("/", (req, res) => {
  db.query("SELECT * FROM criminals", (err, result) => {
    if (err) return res.send(err);
    res.send(result);
  });
});

module.exports = router;
