const express = require("express");
const router = express.Router();
const db = require("../db");

// 🔍 SEARCH CNIC
router.get("/cnic/:cnic", (req, res) => {
  const cnic = req.params.cnic;

  db.query("SELECT * FROM criminals WHERE cnic = ?", [cnic], (err, criminals) => {
    if (err) return res.status(500).json({ error: err });

    db.query("SELECT * FROM fir WHERE cnic = ?", [cnic], (err2, firs) => {
      if (err2) return res.status(500).json({ error: err2 });

      res.json({
        criminalRecord: criminals,
        firRecord: firs
      });
    });
  });
});

// ❌ DELETE BY CNIC
router.delete("/remove/:cnic", (req, res) => {
  const { cnic } = req.params;

  db.query("DELETE FROM fir WHERE cnic = ?", [cnic], (err) => {
    if (err) return res.status(500).json({ error: err });

    db.query("DELETE FROM criminals WHERE cnic = ?", [cnic], (err2, result) => {
      if (err2) return res.status(500).json({ error: err2 });

      if (result.affectedRows === 0) {
        return res.json({ success: false, message: "No record found" });
      }

      res.json({
        success: true,
        message: "Criminal & FIR records deleted"
      });
    });
  });
});

module.exports = router;
