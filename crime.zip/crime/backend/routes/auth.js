const express = require("express");
const db = require("../db");
const router = express.Router();

router.post("/login", (req, res) => {
  const { username, password } = req.body;

  const sql = "SELECT * FROM users WHERE username=? AND password=?";
  db.query(sql, [username, password], (err, result) => {
    if (err) return res.send(err);

    if (result.length > 0) {
      res.send({ success: true, role: result[0].role });
    } else {
      res.send({ success: false });
    }
  });
});

module.exports = router;
