const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/auth");
const criminalRoutes = require("./routes/criminals");
const firRoutes = require("./routes/fir");
const searchRoutes = require("./routes/search");
const path = require("path");
const app = express();
app.use(cors());
app.use(express.json());

app.use("/auth", authRoutes);
app.use("/criminals", criminalRoutes);
app.use("/fir", firRoutes);
app.use("/search", searchRoutes);

app.use(express.static(path.join(__dirname, "../frontend")));


app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
